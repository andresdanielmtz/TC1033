#  TC1003
## Final Project, Object Oriented Computational Thinking, ITESM.

To run this project, please use `g++ o <name> main.cpp` and `./<name>`. 

To-do list: 
- Add use of files .txt
- Finish start menu
- Update UML Diagram 
